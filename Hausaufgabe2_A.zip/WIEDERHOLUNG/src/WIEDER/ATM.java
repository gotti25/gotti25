package WIEDER;

//import java.io.BufferedReader;
//import java.io.InputStreamReader;
import java.io.*;

public class ATM {
	

		
		/**
		 * Main command loop of the ATM
		 * Asks the user to enter a number, and passes this number to the function cashout(...) 
		 * which actually does the calculation and produces money.
		 * If the user enters anything else than an integer number, the loop breaks 
		 * and the program exists
		 */
		public void run() {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			while(true) {
				try {
					System.out.print("Enter the amount to withdraw: ");
					
					
					int amount = Integer.parseInt(br.readLine());
					cashout(amount);
					
					if (amount <= 199) {
						System.out.print("Ok, here is your money, enjoy!" + "\n");
					}
					
					
					else {
					System.out.print("Sorry, not enough money in the bank." + "\n");
					}
				} 
				
				catch (Exception e) {
					break;
				}
			
				
			}
		}
		
		public void cashout(int amount) {
			
		};
		
		/**
		 * Launches the ATM
		 */
		public static void main(String[] args) {
			ATM atm = new ATM();
			atm.run();
		};
	};


