package WIEDER;

import java.util.Random;

public class A {

	//private static Random random;
	
	

	public static void main(String[] args) {
		
		
		

		String s = "Hello World!";
		int[] numberList = new int[15];
		for (int i = 0; i < numberList.length; i++) {
			
			Random random = new Random();
			numberList[i] = random.nextInt(100);
		}
		
		int sum = 0;
		for (int i = 0; i < numberList.length; i++) {
			sum += numberList[i];
		}
		if (sum > 750) {
			System.out.println(s);
			
		}
		//System.out.println("Hello");
	}
}

		


